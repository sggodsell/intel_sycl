       Sycl benchmark tests
       by Sean Godsell
       --------------------

To Build:
   make -s

To Cleanup
   make clean

To run the benchmark test(s), you need to make sure
you have opencl installed and setup, as well as Intel's
oneAPI toolkit base installed.

To make sure your SYCL environment is setup, run the following
Intel SYCL setvars.sh shell script
   source /opt/intel/oneapi/setvars.sh
This will setup a working SYCL environment, and utilities,
which are needed to develop and run SYCL programs.

To view a list of SYCL devices on your system. Type in:
   sycl-ls

   [level_zero:gpu][level_zero:0] Intel(R) oneAPI Unified Runtime over Level-Zero, Intel(R) Arc(TM) Graphics
   [opencl:cpu][opencl:0] Intel(R) OpenCL, Intel(R) Core(TM) Ultra 7 255H OpenCL 3.0 (Build 0)
   [opencl:gpu][opencl:1] Intel(R) OpenCL Graphics, Intel(R) Arc(TM) Graphics OpenCL 3.0 NEO

Switching to other SYCL devices without recompiling your programs
is very fast, and very easy.  Using the example SYCL device table above,
we can choose which SYCL device to use for the benchmark program(s).
Type in the following on a terminal prompt:
   export ONEAPI_DEVICE_SELECTOR=level_zero:0
            or
   export SYCL_DEVICE_ALLOWLIST=level_zero:0
This is make the benchmark program use the oneAPI Unified Runtime
device with the Integrated Arc Graphics device.  Now all you have
to do is run a benchmark command:
   ./simple-sycl-benchmark-test
To use the CPU in this example, type in the following:
   export ONEAPI_DEVICE_SELECTOR=opencl:0
            or
   export SYCL_DEVICE_ALLOWLIST=opencl:0
Now the same benchmark test program will be using the CPU
instead of the Arc Graphics device.

To remove or unset the environment variable, type in the following:
   unset ONEAPI_DEVICE_SELECTOR
            or
   unset SYCL_DEVICE_ALLOWLIST


