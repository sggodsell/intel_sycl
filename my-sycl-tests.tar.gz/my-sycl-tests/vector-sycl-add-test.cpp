#include <sycl/sycl.hpp>
#include <iostream>
#include <vector>

int main() {
    // Define the size of the vectors
    const int N = 4000000;

    // Create host vectors
    std::vector<int> a(N);
    std::vector<int> b(N);
    std::vector<int> c(N);

    // Initialize input vectors
    for (int i = 0; i < N; ++i) {
        a[i] = i;
        b[i] = N - i;
    }

    // Create a SYCL queue to target a device (e.g., GPU)
    sycl::queue q; 
    // You can also use sycl::cpu_selector{} or sycl::default_selector{}

    std::cout << "Running on device: " << q.get_device().get_info<sycl::info::device::name>() << std::endl;

    try {
        // Create SYCL buffers from host vectors
        sycl::buffer<int, 1> buf_a(a.data(), sycl::range<1>(N));
        sycl::buffer<int, 1> buf_b(b.data(), sycl::range<1>(N));
        sycl::buffer<int, 1> buf_c(c.data(), sycl::range<1>(N));

	auto t1 = std::chrono::high_resolution_clock::now();

        // Submit a command group to the queue
        q.submit([&](sycl::handler& cgh) {
            // Create accessors to the buffers for kernel access
            sycl::accessor acc_a(buf_a, cgh, sycl::read_only);
            sycl::accessor acc_b(buf_b, cgh, sycl::read_only);
            sycl::accessor acc_c(buf_c, cgh, sycl::write_only);

            // Define the kernel (parallel_for)
            cgh.parallel_for<class VectorAdd>(sycl::range<1>(N), [=](sycl::id<1> idx) {
                acc_c[idx] = acc_a[idx] + acc_b[idx];
            });
        }).wait(); // Wait for the kernel to complete

	auto t2 = std::chrono::high_resolution_clock::now();
	auto td = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1);

        // Copy results back to host (implicitly handled by buffer destruction or explicitly with accessors)
        // For demonstration, let's explicitly get an accessor to read the results
        sycl::host_accessor host_acc_c(buf_c);
        for (int i = 0; i < N; ++i) {
            c[i] = host_acc_c[i];
        }

        // Verify the results
        bool success = true;
        for (int i = 0; i < N; ++i) {
            if (c[i] != (a[i] + b[i])) {
                success = false;
                break;
            }
        }

        if (success) {
            std::cout << "Vector addition successful! (ran in: " << td.count() << ")" << std::endl;
        } else {
            std::cout << "Vector addition failed." << std::endl;
        }

    } catch (sycl::exception const& e) {
        std::cerr << "SYCL exception caught: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
