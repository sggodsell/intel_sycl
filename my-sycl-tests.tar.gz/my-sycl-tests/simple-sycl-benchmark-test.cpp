// SYCL example code that sums up two vectors
// video Youtube cppcon channel  (GPU Performance Portability using standard C++ with SYCL - Hugh)
//
// compile
//     for cuda
//   clang++ -fsycl --save-temps -fsycl-targets=nvptx64-nvidia-cuda simple-sycl-test.cpp
//     for spir-v
//   clang++ -fsycl --save-temps -fsycl-targets=spir64-unknown-unknown simple-sycl-test.cpp
//     for icpx intel
//   icpx -fsycl simple-sycl-test.cpp
//
// you get an a.out to run
// 
// To get a list of all the sycl devices that your system supports
//    sycl-ls
//    [level_zero:gpu][level_zero:0] Intel(R) oneAPI Unified Runtime over Level-Zero, Intel(R) Arc(TM) Graphics 
//    [opencl:cpu][opencl:0] Intel(R) OpenCL, Intel(R) Core(TM) Ultra 7 255H OpenCL 3.0 
//    [opencl:gpu][opencl:1] Intel(R) OpenCL Graphics, Intel(R) Arc(TM) Graphics OpenCL 3.0 NEO 
//    [ext_openapi_level_zero:gpu:0] Intel Level-Zero, Iris Xe Graphics xxxxxxxx
//    [host:host:0] SYCL host platform, SYCL host device xxxxxxx
//
// To change which sycl device you want to use, then add an environment variable
//    SYCL_DEVICE_ALLOWLIST=opencl:gpu
//    SYCL_DEVICE_ALLOWLIST=opencl:cpu
//    SYCL_DEVICE_ALLOWLIST=opencl:1
//    SYCL_DEVICE_FILTER=host
//       or
//    SYCL_DEVICE_FILTER=gpu
//    ONEAPI_DEVICE_SELECTOR=level_zero:0


//#include <CL/sycl.hpp>
#include <sycl/sycl.hpp>
#include <chrono>

using T = float;

constexpr size_t n = 1000000;

int main() {
	std::vector<T> A(n);
	std::vector<T> B(n);

	for (auto i = 0; i < n; ++i) {
		A[i] = i;
	}

	sycl::queue q{};

	// print out the name of the sycl device we are currently using
	std::cout << "Running on device: "
		  << q.get_device().get_info<sycl::info::device::name>() << std::endl;

	try {
		sycl::buffer bufA{A};
		sycl::buffer bufB{B};

		// get start time
		auto t1 = std::chrono::high_resolution_clock::now();

		// parallel processing on sycl device
		q.submit([&](sycl::handler &cgh) {
			sycl::accessor accA{bufA, cgh};
			sycl::accessor accB{bufB, cgh};

			cgh.parallel_for(sycl::range{n},
					[=](sycl::id<1> i) { accB[i] = accA[i] * accA[i]; });
		}).wait();

		// get end time
		auto t2 = std::chrono::high_resolution_clock::now();
		auto dt	= std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1);
		std::cout << "Vector sum run in: " 
			 << dt.count()
			 << std::endl;

	}
	catch (sycl::exception const& e) {
	}

}

